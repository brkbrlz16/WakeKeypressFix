#!/bin/bash
# WakeUpScr 2.5
#
# Mode file: ~/Library/Application Support/WakeUpScr/mode   (one line)
#   fix [N]  (default: fix 0) - after a real wake, declare user activity
#            (caffeinate -u) N seconds after the wake is noticed, and again N+4 s.
#            fix 0 = fastest (default); fix 1..4 = slower fallbacks if 0 ever misbehaves.
#   quiet    - only notice wakes and log them; does nothing else
#
# No pmset / ioreg / display-state reads in the wake path (they hung this machine).
# The mode file is re-read every ~30 s while idle (never during a wake).
# Log lines are buffered in memory and written 20 s after the wake.
#
#   wakewatch.sh --diag   (run manually while awake) print display/lid state
#   log: ~/Library/Logs/WakeUpScr.log

FLUSH_AGE=20
MODE_FILE="$HOME/Library/Application Support/WakeUpScr/mode"
LOG="$HOME/Library/Logs/WakeUpScr.log"

mode=fix
delay=0
buf=""
note()  { buf="$buf$(date '+%F %T') $*"$'\n'; }
flush() { printf '%s' "$buf" >> "$LOG"; buf=""; }

# sets globals: mode, delay
read_mode() {
    local line rest
    line=$(cat "$MODE_FILE" 2>/dev/null)
    line=${line:-fix}
    mode=${line%% *}
    rest=${line#"$mode"}
    rest=${rest// /}
    if [[ $rest =~ ^[0-9]+$ ]]; then delay=$rest; else delay=0; fi
    [[ $mode == quiet ]] || mode=fix
}

if [[ $1 == --diag ]]; then
    read_mode
    echo "display (pmset): '$(pmset -g powerstate 2>/dev/null | awk '/IODisplayWrangler/ {print $2; exit}')'  (4 = on)"
    pm=$(ioreg -rl -n IOPMrootDomain -d1 -w0 2>/dev/null)
    echo "wake reason    : $(printf '%s\n' "$pm" | grep -i 'wake reason')"
    echo "lid state      : $(printf '%s\n' "$pm" | grep 'AppleClamshellState"')"
    echo "mode           : $mode (delay $delay)"
    exit 0
fi

mkdir -p "$(dirname "$LOG")"
read_mode
buf="$(date '+%F %T') started (pid $$, mode $mode, delay $delay)"$'\n'
flush

prev=$(date +%s)
wake_at=0
flushed=1
poked1=1
poked2=1

while true; do
    sleep 1
    now=$(date +%s)
    if (( now - prev > 4 )); then
        wake_at=$now; flushed=0; poked1=0; poked2=0; buf=""
        note "wake detected (slept ~$((now - prev))s)"
    fi
    prev=$now

    if (( wake_at == 0 )); then
        (( now % 30 == 0 )) && read_mode
        continue
    fi
    age=$((now - wake_at))

    if [[ $mode == fix ]]; then
        if (( poked1 == 0 && age >= delay )); then
            poked1=1; caffeinate -u -t 1; note "poke #1 at +${age}s"
        elif (( poked2 == 0 && age >= delay + 4 )); then
            poked2=1; caffeinate -u -t 1; note "poke #2 at +${age}s"
        fi
    fi

    if (( flushed == 0 && age >= FLUSH_AGE )); then
        note "alive at +${age}s (mode $mode, delay $delay)"
        flush
        flushed=1
        read_mode
    elif (( flushed == 1 && age > 60 && now % 30 == 0 )); then
        read_mode
    fi
done
